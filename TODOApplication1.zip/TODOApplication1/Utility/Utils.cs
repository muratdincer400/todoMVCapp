﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TODOApplication1.Models;
namespace TODOApplication1.Utility
{
    public static class Utils
    {

        public static void AddTestData(InMemDbContext context)
        {
            var todoitem1 = new ToDoList() { Id = 1, Description = "Wash your hands", IsDone = false };

            context.ToDoLists.Add(todoitem1);

            var todoitem2 = new ToDoList() { Id = 2, Description = "Read newspaper", IsDone = false };

            context.ToDoLists.Add(todoitem1);

            var todoitem3= new ToDoList() { Id = 3, Description = "Fix television", IsDone = false };

            context.ToDoLists.Add(todoitem1);
            context.SaveChanges();
        }
    }
}
