﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TODOApplication1.Models
{
    public partial class ToDoList
    {
        public int Id { get; set; }
        public string Description { get; set; }
        public bool? IsDone { get; set; }
    }
}
