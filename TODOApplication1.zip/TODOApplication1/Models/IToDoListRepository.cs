﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TODOApplication1.Models
{
    public interface IToDoListRepository
    {

        ToDoList GetToDoList(int Id);
        IEnumerable<ToDoList> GetAll();
        ToDoList Add(ToDoList todolist);
        ToDoList Update(ToDoList todolistChanges);
        ToDoList Delete(int id);
    }
}