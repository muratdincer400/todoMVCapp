﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TODOApplication1.Models
{
    public class InMemDbContext:DbContext
    {
        public InMemDbContext(DbContextOptions<InMemDbContext> options)
            : base(options)
        {

        }

        public virtual DbSet<ToDoList> ToDoLists { get; set; }

    }
}
