﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TODOApplication1.Models
{
    public class MockToDoListRepository : IToDoListRepository
    {
        private List<ToDoList> _todoList;
        public MockToDoListRepository()
        {
            if (_todoList==null)
            {
                _todoList = new List<ToDoList>()
            {
                new ToDoList() { Id = 1, Description = "Wash the dishes", IsDone = false },
                new ToDoList() { Id = 2, Description = "Prepare presentation for work", IsDone = false },
                new ToDoList() { Id = 3, Description = "Repair laptop", IsDone = false }
            };

            }
            
        }
        public ToDoList Add(ToDoList todolist)
        {
            todolist.Id = _todoList.Max(e => e.Id + 1);
            _todoList.Add(todolist);
            return todolist;
        }

        public ToDoList Delete(int id)
        {
            ToDoList todolist = _todoList.FirstOrDefault(e => e.Id == id);
            if (todolist!=null)
            {
                _todoList.Remove(todolist);
                    
            }
            return todolist;
        }

        public IEnumerable<ToDoList> GetAll()
        {
            return _todoList;
        }

        public ToDoList GetToDoList(int Id)
        {
            return _todoList.FirstOrDefault(e => e.Id == Id);
        }

        public ToDoList Update(ToDoList todolistChanges)
        {
            ToDoList todolist = _todoList.FirstOrDefault(e => e.Id == todolistChanges.Id);
            if (todolist != null)
            {
                todolist.Id=todolistChanges.Id;
                todolist.Description = todolistChanges.Description;
                todolist.IsDone = todolistChanges.IsDone;
            }
            return todolist;
        }
    }


    
}
