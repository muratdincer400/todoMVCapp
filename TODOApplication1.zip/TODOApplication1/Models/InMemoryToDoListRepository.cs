﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TODOApplication1.Models
{
    public class InMemoryToDoListRepository : IToDoListRepository
    {
        private readonly InMemDbContext context;
        public InMemoryToDoListRepository(InMemDbContext context)
        {
            this.context = context;
        }
        public ToDoList Add(ToDoList todolist)
        {
            context.ToDoLists.Add(todolist);
            context.SaveChanges();
            return todolist;
        }

        public ToDoList Delete(int id)
        {
            ToDoList todolist = context.ToDoLists.Find(id);
            if (todolist!=null)
            {
                context.ToDoLists.Remove(todolist);
                context.SaveChanges();
            }
            return todolist;
        }

        public IEnumerable<ToDoList> GetAll()
        {
            return context.ToDoLists;
        }

        public ToDoList GetToDoList(int Id)
        {
            return context.ToDoLists.Find(Id);
        }

        public ToDoList Update(ToDoList todolistChanges)
        {
            var todoitem=context.ToDoLists.Attach(todolistChanges);
            todoitem.State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            context.SaveChanges();
            return todolistChanges;

        }
    }
}
